import { useState } from 'react';

function InputComponent({ field }) {
  const [value, setValue] = useState('');

  const fieldClassName = value ? 'has-value' : '';

  if (field.type === 'select') {
    return (
      <div className="form-field">
        <label htmlFor={field.name}>{field.label}</label>

        <select
          id={field.name}
          name={field.name}
          value={value}
          onChange={(event) => setValue(event.target.value)}
          className={fieldClassName}
        >
          <option value="" disabled>
            Selecione {field.label.toLowerCase()}
          </option>

          {field.options?.map((option) => (
            <option key={option} value={option}>
              {option}
            </option>
          ))}
        </select>
      </div>
    );
  }

  return (
    <div className="form-field">
      <label htmlFor={field.name}>{field.label}</label>

      <input
        id={field.name}
        name={field.name}
        type={field.type || 'text'}
        value={value}
        onChange={(event) => setValue(event.target.value)}
        placeholder={`Informe ${field.label.toLowerCase()}`}
        className={fieldClassName}
      />
    </div>
  );
}

export default InputComponent;
