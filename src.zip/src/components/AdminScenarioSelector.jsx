import './AdminScenarioSelector.css';

const availableScenarios = [
  {
    key: 'academia',
    icon: '🥋',
    title: 'Academia Rangel',
    description:
      'Gestão de alunos, professores, aulas, mensalidades e estoque.',
    modules: 'Alunos, Professores, Aulas, Financeiro, Estoque e Relatórios',
  },
  {
    key: 'borracharia',
    icon: '🛞',
    title: 'Borracharia Rangel',
    description:
      'Gestão de veículos, clientes, serviços, financeiro e estoque.',
    modules: 'Veículos, Clientes, Serviços, Financeiro, Estoque e Relatórios',
  },
];

function AdminScenarioSelector({
  user,
  scenarios,
  onSelectScenario,
  onLogout,
}) {
  const scenarioCards = availableScenarios.filter(
    (scenario) => scenarios[scenario.key]
  );

  return (
    <main className="admin-selector-page">
      <section className="admin-selector-card">
        <div className="admin-selector-header">
          <div>
            <p className="admin-selector-kicker">Sistema parametrizável</p>
            <h1>Escolha qual sistema deseja acessar</h1>
            <span>
              Olá, {user.name}. Como administradora geral, você pode acessar os
              ambientes configurados na plataforma.
            </span>
          </div>

          <button
            type="button"
            className="admin-logout-button"
            onClick={onLogout}
          >
            Sair
          </button>
        </div>

        <div className="admin-scenario-grid">
          {scenarioCards.map((scenario) => (
            <button
              key={scenario.key}
              type="button"
              className="admin-scenario-card"
              onClick={() => onSelectScenario(scenario.key)}
            >
              <div className="admin-scenario-icon">{scenario.icon}</div>

              <div className="admin-scenario-content">
                <strong>{scenario.title}</strong>
                <p>{scenario.description}</p>
                <small>{scenario.modules}</small>
              </div>

              <span className="admin-scenario-action">Acessar sistema</span>
            </button>
          ))}
        </div>
      </section>
    </main>
  );
}

export default AdminScenarioSelector;
