import InputComponent from './InputComponent';
import ButtonComponent from './ButtonComponent';

function FormComponent({ fields, entity, description }) {
  function handleSubmit(event) {
    event.preventDefault();
  }

  return (
    <section className="card form-card">
      <div className="section-title">
        <span>Cadastro</span>
        <h2>{entity}</h2>
        {description && <p>{description}</p>}
      </div>

      <form className="form" onSubmit={handleSubmit}>
        {fields.map((field) => (
          <InputComponent key={field.name} field={field} />
        ))}

        <div className="actions">
          <ButtonComponent label="Salvar" type="submit" />
          <ButtonComponent label="Cancelar" variant="secondary" />
        </div>
      </form>
    </section>
  );
}

export default FormComponent;
