import ButtonComponent from './ButtonComponent';

function ReportsComponent({ config }) {
  const crudModules = config.modules.filter((module) => module.type === 'crud');

  return (
    <section className="card">
      <div className="section-title">
        <span>Consulta</span>
        <h2>Relatórios</h2>
        <p>
          Tela de relatórios configurada com base nos módulos disponíveis para o
          cenário selecionado.
        </p>
      </div>

      <div className="report-form">
        <div className="form-field">
          <label>Tipo de relatório</label>
          <select>
            {crudModules.map((module) => (
              <option key={module.key}>Registros de {module.entity}</option>
            ))}
          </select>
        </div>

        <div className="form-field">
          <label>Formato</label>
          <select>
            <option>Tela</option>
            <option>PDF</option>
            <option>Excel</option>
          </select>
        </div>

        <div className="form-field">
          <label>Data inicial</label>
          <input type="date" />
        </div>

        <div className="form-field">
          <label>Data final</label>
          <input type="date" />
        </div>

        <ButtonComponent label="Gerar relatório" />
      </div>
    </section>
  );
}

export default ReportsComponent;
